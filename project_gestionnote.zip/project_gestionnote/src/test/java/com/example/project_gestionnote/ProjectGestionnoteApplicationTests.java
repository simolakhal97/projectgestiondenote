package com.example.project_gestionnote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectGestionnoteApplicationTests {

    @Test
    void contextLoads() {
    }

}
