<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap 5 Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <div class="container-fluid p-5 bg-primary text-white text-center">
        <h1>welcome to your acount</h1>
        <p>mohammed lakhal  </p>
    </div>

    <table class="table">
        <thead class="table-dark">
            <tr>
                <th scope="col">profe </th>
                <th scope="col">gmail</th>
                <th scope="col">password</th>
                <th scope="col">filier</th>
                <th scope="col">delete</th>
            </tr>
        </thead>
        <tbody>
       
        
     
            <tr>
                <th scope="row"><input type="text" value="mohammed lkhal" name="n1"></th>
                <td><input type="text" value="mohammed@gmail.com" name="n1"></td>
                <td><input type="text" value="5645fdx$" name="n1"></td>
                <td><input type="text" value="java"name="n1"></td>
                <td><button>X</button></td>
                
            </tr>
         

        </tbody>
    </table>
    <button type="button" class="btn btn-primary" style="float: right; margin-right: 50px;">save</button>

    <button type="button" class="btn btn-primary" style="float: right; margin-right: 50px;">add</button>
</body>

</html>