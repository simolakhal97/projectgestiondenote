<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap 5 Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <div class="container-fluid p-5 bg-primary text-white text-center">
        <h1>welcome to your acount</h1>
        <p>mohammed lakhal  </p>
    </div>

    <table class="table">
        <thead class="table-dark">
            <tr>
                <th scope="col">Etudiant </th>
                <th scope="col">1eme note</th>
                <th scope="col">2eme note</th>
                <th scope="col">EFM</th>
                <th scope="col">note total</th>
            </tr>
        </thead>
        <tbody>
       
        
     
            <tr>
                <th scope="row">mohammed lkhal</th>
                <td><input type="number" value="19.00" name="n1"></td>
                <td><input type="number" value="19.00" name="n1"></td>
                <td><input type="number" value="19.00"name="n1"></td>
                <td><input type="number" value="19.00"name="n1"></td>
            </tr>
         

        </tbody>
    </table>
    <button type="button" class="btn btn-primary" style="float: right; margin-right: 50px;">save</button>
</body>

</html>