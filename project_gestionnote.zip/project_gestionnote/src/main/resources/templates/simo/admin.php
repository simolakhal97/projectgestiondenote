<?xml version="1.0" encoding="UTF-8" ?>
<jsp:root xmlns:jsp="http://java.sun.com/JSP/Page" version="2.3">
   <jsp:directive.page contentType="text/html" />
   <jsp:text>&lt;!DOCTYPE html&gt;</jsp:text>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap 5 Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<form th:action="@{/Admin}" method="post" enctype="multipart/form-data">

    <div class="container-fluid p-5 bg-primary text-white text-center">
        <h1>welcome to your acount</h1>
        <p>mohammed lakhal </p>
    </div>

    <div class="btn-group" role="group" aria-label="Basic mixed styles example" style="display: block; margin:20vh  0 0 30%;">
        <a href="admin_etd.html"><button type="button" class="btn btn-danger" style="width: 300px;height: 200px;">Etudian</button></a>
   
        <a href="admin_prf.html"> <button type="button" class="btn btn-success" style="width: 300px;height: 200px;">Profe</button></a>
      </div>
      <form >
</body>

</html>
</jsp:root>
