<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap 5 Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <!-- <nav class="navbar navbar-light bg-light">
        <div class="container-fluid"  style="text-align: center; display: block;">
          <span class="navbar-brand mb-0 h1">welcome to your acount </span>
        </div>
      </nav> -->
    <div class="container-fluid p-5 bg-primary text-white text-center">
        <h1>welcome to your acount</h1>
        <p>mohammed lakhal  </p>
    </div>





    <table class="table">
        <thead class="table-dark">
            <tr>
                <th scope="col">matier</th>
                <th scope="col">1eme note</th>
                <th scope="col">2eme note</th>
                <th scope="col">EFM</th>
                <th scope="col">note total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">physique</th>
                <td>14.25</td>
                <td>14.25</td>
                <td>14.25</td>
                <td>14.25</td>
            </tr>
            <!-- <tr>
                <th scope="row">physique</th>
                <td>14.25</td>
                <td>14.25</td>
                <td>14.25</td>
                <td>14.25</td>
              </tr> -->

        </tbody>
    </table>

</body>

</html>