package com.example.project_gestionnote.Controller;

import com.example.project_gestionnote.Service.NoteService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class NoteController {
    private NoteService noteService;

    public NoteController(NoteService NoteService){
        noteService=NoteService;
    }
    @GetMapping("")
    @RequestMapping(value="/Note",method= RequestMethod.POST)
    public Model ListNote(Model model){
        model.addAttribute("Note",noteService.getAllNote());
        return model;
    }
}
