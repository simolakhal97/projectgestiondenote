package com.example.project_gestionnote.Model;

import org.springframework.data.annotation.Id;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

public class Admin {
    @Id @GeneratedValue( strategy= GenerationType.IDENTITY)
    private long idA;
    private String nom;
    private String prenom;
    private String EmailAdmin;
    private String PasswordAdmin;
@OneToMany( targetEntity=Etudiant.class, mappedBy="Admin" )
private List<Etudiant> etudiantList = new ArrayList<>();

    @ManyToOne
    @JoinColumn( name="idL" )
    private Login login;

    public String getPasswordAdmin() {
        return PasswordAdmin;
    }

    public void setPasswordAdmin(String passwordAdmin) {
        PasswordAdmin = passwordAdmin;
    }

    public String getEmailAdmin() {
        return EmailAdmin;
    }

    public void setEmailAdmin(String emailAdmin) {
        EmailAdmin = emailAdmin;
    }

    public Admin() {
    }
    public Admin(long idA, String nom, String prenom) {
        this.idA = idA;
        this.nom = nom;
        this.prenom = prenom;
    }
    public long getId() {
        return idA;
    }

    public void setId(long id) {
        this.idA = idA;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }


}