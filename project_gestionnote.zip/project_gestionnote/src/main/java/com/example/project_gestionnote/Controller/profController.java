package com.example.project_gestionnote.Controller;

import com.example.project_gestionnote.Service.ProfService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class profController {
    private ProfService profService;

    public profController(ProfService ProfService){
        profService=ProfService;
    }
    @GetMapping("")
    @RequestMapping(value="/prof",method= RequestMethod.POST)
    public Model ListProf(Model model){
        model.addAttribute("prof",profService.getAllProf());
        return model;
    }
}
