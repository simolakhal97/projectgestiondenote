package com.example.project_gestionnote.Service;

import com.example.project_gestionnote.DTO.LoginDTO;

import java.util.List;

public interface LoginService {
    public List<LoginDTO> getAllLogin();
}
