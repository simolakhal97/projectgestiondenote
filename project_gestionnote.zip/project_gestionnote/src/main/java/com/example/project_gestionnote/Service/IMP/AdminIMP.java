package com.example.project_gestionnote.Service.IMP;
import com.example.project_gestionnote.DTO.AdminDTO;
import com.example.project_gestionnote.Mapper.AdminMapp;
import com.example.project_gestionnote.Service.AdminService;
import com.example.project_gestionnote.Reppo.AdminReppo;
import com.example.project_gestionnote.Model.Admin;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminIMP implements AdminService {
    private AdminReppo adminReppo;
    private Object Admin;
    public AdminIMP(AdminReppo AdminReppo){
    adminReppo=AdminReppo;

    }

    @Override
    public List<AdminDTO> getAllAdmin() {
        return adminReppo.findAll().
                stream()
                .map(a-> AdminMapp.mapAdmintoadminDTO(a))
                .collect(Collectors.toList());
    }

    public Admin addAdmin( Admin admin) {
        return adminReppo.save(admin);
    }

    public Admin getAdminById(int idA) {
        return adminReppo.findById((long) idA).get();
    }

    public void updateAdmin(Admin admin) {
        Admin AdminDB = adminReppo.findById(admin.getId()).orElseThrow();
        adminReppo.save(admin);
    }

    public void deleteAdminById(int idA) {
        try {
            adminReppo.deleteById((long) idA);
        }catch(DataAccessException ex){
            throw new RuntimeException(ex.getMessage());
        }
    }

}
