package com.example.project_gestionnote.DTO;

public class LoginDTO {
    private long idL;
    private String email;
    private String password;

    public long getId() {
        return idL;
    }

    public void setId(long id) {
        this.idL = idL;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
