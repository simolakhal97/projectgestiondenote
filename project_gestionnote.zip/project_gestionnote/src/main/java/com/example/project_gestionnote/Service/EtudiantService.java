package com.example.project_gestionnote.Service;
import com.example.project_gestionnote.DTO.EtudiantDTO;

import java.util.List;

public interface EtudiantService {
    public List<EtudiantDTO>getAllEtudiant();
}
