package com.example.project_gestionnote.Controller;

import com.example.project_gestionnote.Service.LoginService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class LoginController {
    private LoginService loginService;
    public LoginController(LoginService LoginService){
        loginService=LoginService;
    }
    @PostMapping("")
    @RequestMapping(value="/Login",method= RequestMethod.POST)
    public Model ListLogin(Model model){
        model.addAttribute("Login",loginService.getAllLogin());
        return model;
    }
}
