package com.example.project_gestionnote.Reppo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.project_gestionnote.Model.Etudiant;
import org.springframework.stereotype.Repository;

@Repository
public interface EtudiantReppo extends JpaRepository<Etudiant,Long> {
}
