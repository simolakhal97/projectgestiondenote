package com.example.project_gestionnote.Reppo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.project_gestionnote.Model.Prof;
@Repository
public interface ProfReppo extends JpaRepository<Prof,Long> {

}
