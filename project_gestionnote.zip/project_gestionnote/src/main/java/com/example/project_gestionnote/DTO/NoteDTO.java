package com.example.project_gestionnote.DTO;

public class NoteDTO {
    private long idN;
    public String notepremier;
    public String notedernier;
    public String notetotale;
    public String coef;

    public long getId() {
        return idN;
    }

    public void setId(long id) {
        this.idN = idN;
    }

    public String getNotepremier() {
        return notepremier;
    }

    public void setNotepremier(String notepremier) {
        this.notepremier = notepremier;
    }

    public String getNotedernier() {
        return notedernier;
    }

    public void setNotedernier(String notedernier) {
        this.notedernier = notedernier;
    }

    public String getNotetotale() {
        return notetotale;
    }

    public void setNotetotale(String notetotale) {
        this.notetotale = notetotale;
    }

    public String getCoef() {
        return coef;
    }

    public void setCoef(String coef) {
        this.coef = coef;
    }
}
