package com.example.project_gestionnote.Mapper;

import com.example.project_gestionnote.DTO.LoginDTO;
import com.example.project_gestionnote.Model.Login;

public class LoginMapp {

public static LoginDTO mapLogintoLoginDTO(LoginDTO Login){
    LoginDTO loginDTO=new LoginDTO();
    loginDTO.setId(Login.getId());
    loginDTO.setEmail(Login.getEmail());
    loginDTO.setPassword(Login.getPassword());


        return loginDTO;
        }
public static Login mapLoginDTOLogin(LoginDTO LoginDTO){
    Login login=new Login();
    login.setId(LoginDTO.getId());
    login.setEmail(LoginDTO.getEmail());
    login.setPassword(LoginDTO.getPassword());

        return login;
        }
}