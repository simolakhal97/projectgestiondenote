package com.example.project_gestionnote.Model;

import org.springframework.data.annotation.Id;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Note {
    @Id @GeneratedValue( strategy= GenerationType.IDENTITY)
    private long idN;
    public String notepremier;
    public String notedernier;
    public String notetotale;
    public String coef;

    public Note() {
    }
    @ManyToOne
    @JoinColumn( name="idE" )
    private Etudiant etudiant;

    @ManyToOne
    @JoinColumn( name="idP" )
    private Prof prof;
    public Note(long idN, String notepremier, String notedernier, String notetotale, String coef) {
        this.idN = idN;
        this.notepremier = notepremier;
        this.notedernier = notedernier;
        this.notetotale = notetotale;
        this.coef = coef;
    }

    public long getId() {
        return idN;
    }

    public void setId(long id) {
        this.idN = idN;
    }

    public String getNotepremier() {
        return notepremier;
    }

    public void setNotepremier(String notepremier) {
        this.notepremier = notepremier;
    }

    public String getNotedernier() {
        return notedernier;
    }

    public void setNotedernier(String notedernier) {
        this.notedernier = notedernier;
    }

    public String getNotetotale() {
        return notetotale;
    }

    public void setNotetotale(String notetotale) {
        this.notetotale = notetotale;
    }

    public String getCoef() {
        return coef;
    }

    public void setCoef(String coef) {
        this.coef = coef;
    }
}
