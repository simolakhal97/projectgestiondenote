package com.example.project_gestionnote.Model;

import org.springframework.data.annotation.Id;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@EntityListeners({Etudiant.class})
public class Etudiant {
    @Id @GeneratedValue( strategy= GenerationType.IDENTITY)
    private long idE;
    private  String nometudient;
    private String  prenom;
    private String email;
    private String bronch;
    private String Epassword;


    @ManyToOne  @JoinColumn( name="idA" )
    private Admin admin;


    @OneToMany( targetEntity=Note.class, mappedBy="Etudiant" )
    private List<Note> notes = new ArrayList<>();
    private Note note;

    @OneToMany( targetEntity=Matier.class, mappedBy="Etudiant" )
    private List<Matier> matiers = new ArrayList<>();
    private Matier matier;

    public Etudiant() {
    }

    public void setEpassword(String epassword) {
        Epassword = epassword;
    }

    public long getId() {
        return idE;
    }

    public void setId(long id) {
        this.idE = idE;
    }

    public String getNometudient() {
        return nometudient;
    }

    public void setNometudient(String nometudient) {
        this.nometudient = nometudient;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBronch() {
        return bronch;
    }

    public void setBronch(String bronch) {
        this.bronch = bronch;
    }
}
