package com.example.project_gestionnote.Service;
import com.example.project_gestionnote.DTO.ProfDTO;

import java.util.List;

public interface ProfService {
    public List<ProfDTO>getAllProf();
}
