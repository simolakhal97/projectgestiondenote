package com.example.project_gestionnote.Service.IMP;
import com.example.project_gestionnote.Service.MatierService;
import com.example.project_gestionnote.DTO.MatierDTO;
import com.example.project_gestionnote.Model.Matier;
import com.example.project_gestionnote.Reppo.MatierReppo;
import com.example.project_gestionnote.Mapper.MatierMapp;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class MatierIMP implements MatierService{
    public static MatierService matierService;
    public Object Matier;
    public MatierIMP(MatierService MatierService){matierService=MatierService;}

    @Override
    public List<MatierDTO> getAllMatier() {
        return matierService.getAllMatier().stream().map(e->MatierMapp.mapMatiertoMatierDTO(e))
                .collect(Collectors.toList());
    }
}
