package com.example.project_gestionnote.Mapper;
import com.example.project_gestionnote.Model.Prof;
import com.example.project_gestionnote.DTO.ProfDTO;
import com.example.project_gestionnote.Model.Note;

public class ProfMapp {

    public static ProfDTO mapProftoPrfDTO(Prof Prof){
        ProfDTO profDTO=new ProfDTO();
        profDTO.setId(Prof.getId());
        profDTO.setPrenom(Prof.getPrenom());
        profDTO.setNom(Prof.getNom());
        profDTO.setMail(Prof.getMail());
        profDTO.setPpasword(Prof.getPpasword());
        profDTO.setFilier(Prof.getFilier());

        return profDTO;
    }
    public static Prof mapProfDTOProf(ProfDTO ProfDTO){
        Prof prof=new Prof();
        prof.setId(ProfDTO.getId());
        prof.setPrenom(ProfDTO.getPrenom());
        prof.setNom(ProfDTO.getNom());
        prof.setMail(ProfDTO.getMail());
        prof.setPpasword(ProfDTO.getPpasword());
        prof.setFilier(ProfDTO.getFilier());
        return prof;
    }
}
