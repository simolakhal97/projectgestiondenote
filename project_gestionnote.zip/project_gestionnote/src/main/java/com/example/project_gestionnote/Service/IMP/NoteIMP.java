package com.example.project_gestionnote.Service.IMP;
import com.example.project_gestionnote.Service.NoteService;
import com.example.project_gestionnote.DTO.NoteDTO;
import com.example.project_gestionnote.Model.Note;
import com.example.project_gestionnote.Reppo.NoteReppo;
import com.example.project_gestionnote.Mapper.NoteMapp;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NoteIMP implements NoteService{
    public static NoteService noteService;
    public Object Note;
    public NoteIMP(NoteService NoteService){noteService=NoteService;}

    @Override
    public List<NoteDTO> getAllNote() {
        return noteService.getAllNote().stream().map(e->NoteMapp.mapNotetoNoteDTO(e))
                .collect(Collectors.toList());
    }
}
