package com.example.project_gestionnote.Service.IMP;
import com.example.project_gestionnote.Model.Admin;
import com.example.project_gestionnote.Service.ProfService;
import com.example.project_gestionnote.DTO.ProfDTO;
import com.example.project_gestionnote.Model.Prof;
import com.example.project_gestionnote.Reppo.ProfReppo;
import com.example.project_gestionnote.Mapper.ProfMapp;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class ProfIMP implements ProfService{
    public Object Prof;
    public  ProfReppo profReppo;
    public ProfIMP(ProfReppo ProfReppo){profReppo=ProfReppo;}
    @Override
    public List<ProfDTO> getAllProf() {
        return profReppo.findAll()
                .stream()
                .map(e->ProfMapp.mapProftoPrfDTO(e))
                .collect(Collectors.toList());
    }

    public  Prof AddProf(Prof prof){
        return profReppo.save(prof);
    }

    public Prof getProfById(int idP) {
        return profReppo.findById((long) idP).get();
    }

    public void updateProf(Prof prof) {
        Prof profDB = profReppo.findById(prof.getId()).orElseThrow();
        profDB.save(prof);
    }

    public void deleteProfById(int idP) {
        try {
          profReppo.deleteById((long) idP);
        }catch(DataAccessException ex){
            throw new RuntimeException(ex.getMessage());
        }
    }
}
