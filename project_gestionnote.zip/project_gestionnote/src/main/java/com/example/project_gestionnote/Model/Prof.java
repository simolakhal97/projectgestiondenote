package com.example.project_gestionnote.Model;

import org.springframework.data.annotation.Id;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

public class Prof {
    @Id @GeneratedValue( strategy= GenerationType.IDENTITY)
    private long idP;
    public String nom;
    public String prenom;
    public String mail;
    public String Ppasword;
    public String filier;

    @OneToMany( targetEntity=Note.class, mappedBy="Prof" )
    private List<Note> notes = new ArrayList<>();
    private Note note;

    @OneToMany( targetEntity=Matier.class, mappedBy="Prof" )
    private List<Matier> matiers = new ArrayList<>();
    private Matier matier;


    @ManyToOne
    @JoinColumn( name="idL" )
    private Login login;


    public String getPpasword() {
        return Ppasword;
    }

    public void setPpasword(String ppasword) {
        Ppasword = ppasword;
    }

    public String getFilier() {
        return filier;
    }

    public void setFilier(String filier) {
        this.filier = filier;
    }
    public Prof() {
    }

    public Prof(long idP, String nom, String prenom, String mail) {
        this.idP = idP;
        this.nom = nom;
        this.prenom = prenom;
        this.mail = mail;
    }

    public long getId() {
        return idP;
    }

    public void setId(long id) {
        this.idP = idP;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void save(Prof prof) {
    }
}
