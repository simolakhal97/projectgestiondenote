package com.example.project_gestionnote.Mapper;
import com.example.project_gestionnote.DTO.AdminDTO;
import com.example.project_gestionnote.Model.Admin;
public class AdminMapp {
    public static AdminDTO mapAdmintoadminDTO(Admin Admin){
        AdminDTO adminDTO =new AdminDTO();
        adminDTO.setId(Admin.getId());
        adminDTO.setNom(Admin.getNom());
        adminDTO.setEmailAdmin(Admin.getEmailAdmin());
        adminDTO.setPrenom(Admin.getPrenom());
        adminDTO.setPasswordAdmin(Admin.getPasswordAdmin());
        return adminDTO;
    }

    public static Admin mapAdminDTOAdmin(AdminDTO AdminDTO){
        Admin admin =new Admin();
        admin.setId(AdminDTO.getId());
        admin.setNom(AdminDTO.getNom());
        admin.setEmailAdmin(AdminDTO.getEmailAdmin());
        admin.setPrenom(AdminDTO.getPrenom());
        admin.setPasswordAdmin(AdminDTO.getPasswordAdmin());
        return admin;
    }
}
