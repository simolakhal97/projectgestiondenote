package com.example.project_gestionnote.Controller;
import com.example.project_gestionnote.DTO.AdminDTO;
import com.example.project_gestionnote.Model.Admin;
import com.example.project_gestionnote.Service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

public class AdminController {
@Autowired
    private AdminService adminservice;
    private Object Admin;

    public AdminController(AdminService AdminService){
        adminservice=AdminService;
    }
    @PostMapping("")
    @RequestMapping(value="/Admin",method= RequestMethod.POST)
    public Model ListAdmin(Model model){
        model.addAttribute("Admin",adminservice.getAllAdmin());
                return model;
    }


    @RequestMapping(value="/save",method = RequestMethod.POST)
    public String save(@ModelAttribute("Admin") Admin admin){
        AdminDTO.save(admin);
        return "Admin";//will redirect to viewemp request mapping
    }


}

