package com.example.project_gestionnote.Mapper;
import com.example.project_gestionnote.DTO.EtudiantDTO;
import com.example.project_gestionnote.Model.Etudiant;
public class EtudiantMapp {
    public static EtudiantDTO mapEtudianttoEtudiantDTO(EtudiantDTO Etudiant){
        EtudiantDTO etudiantDTO=new EtudiantDTO();
        etudiantDTO.setId(Etudiant.getId());
       etudiantDTO.setNometudient(Etudiant.getNometudient());
       etudiantDTO.setPrenom(Etudiant.getPrenom());
       etudiantDTO.setBronch(Etudiant.getBronch());
       etudiantDTO.setEpassword(Etudiant.getEpassword());
       etudiantDTO.setEmail(Etudiant.getEmail());
       return etudiantDTO;
    }
    public static Etudiant mapEtudiantDTOEtudiant(EtudiantDTO EtudiantDTO){
        Etudiant etudiant=new Etudiant();
        etudiant.setId(EtudiantDTO.getId());
        etudiant.setNometudient(EtudiantDTO.getNometudient());
        etudiant.setPrenom(EtudiantDTO.getPrenom());
        etudiant.setBronch(EtudiantDTO.getBronch());
        etudiant.setEmail(EtudiantDTO.getEmail());
        etudiant.setEpassword(EtudiantDTO.getEpassword());
        return etudiant;
    }
}
