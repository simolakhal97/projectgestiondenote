package com.example.project_gestionnote.DTO;

public class MatierDTO {
    private long idM;
    private String nomfilier;
    private  String libelle;


    public long getId() {
        return idM;
    }

    public void setId(long id) {
        this.idM = idM;
    }

    public String getNomfilier() {
        return nomfilier;
    }

    public void setNomfilier(String nomfilier) {
        this.nomfilier = nomfilier;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
}
