package com.example.project_gestionnote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties;

import java.sql.Connection;
import java.sql.DriverManager;

@SpringBootApplication
public class ProjectGestionnoteApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectGestionnoteApplication.class, args);
       Connection conn = null;

        try {
            String userName = "root";
            String password = "root";

            String url = "jjdbc:mysql://localhost:8889/mydatabese_gestion_note";
            Class.forName("com.mysql.jjdbc.Driver").newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            System.out.println("Database connection established");
        } catch (Exception e) {
            System.err.println("Cannot connect to database server");
            System.err.println(e.getMessage());
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                    System.out.println("Database Connection Terminated");
                } catch (Exception e) {}
            }
        }
    }
}
