package com.example.project_gestionnote.Reppo;

import com.example.project_gestionnote.DTO.AdminDTO;
import com.example.project_gestionnote.Model.Admin;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface AdminReppo extends JpaRepository<Admin,Long>{


}
