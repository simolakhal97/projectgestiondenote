package com.example.project_gestionnote.Reppo;
import com.example.project_gestionnote.Model.Matier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MatierReppo extends JpaRepository<Matier,Long> {
}
