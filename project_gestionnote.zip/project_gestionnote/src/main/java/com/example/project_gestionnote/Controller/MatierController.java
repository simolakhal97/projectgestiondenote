package com.example.project_gestionnote.Controller;

import com.example.project_gestionnote.Service.EtudiantService;
import org.springframework.ui.Model;
import com.example.project_gestionnote.Service.MatierService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class MatierController {
    private MatierService matierService;

    public MatierController(MatierService MatierService){
        matierService=MatierService;
    }
    @PostMapping("")
    @RequestMapping(value="/Matier",method= RequestMethod.POST)
    public Model ListMatier(Model model){
        model.addAttribute("Matier",matierService.getAllMatier());
        return model;
    }
}
