package com.example.project_gestionnote.Service;
import com.example.project_gestionnote.DTO.NoteDTO;

import java.util.List;

public interface NoteService {
    public List<NoteDTO>getAllNote();
}
