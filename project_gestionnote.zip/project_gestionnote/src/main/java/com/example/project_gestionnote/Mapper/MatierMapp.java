package com.example.project_gestionnote.Mapper;

import com.example.project_gestionnote.DTO.EtudiantDTO;
import com.example.project_gestionnote.Model.Etudiant;
import com.example.project_gestionnote.DTO.MatierDTO;
import com.example.project_gestionnote.Model.Matier;
public class MatierMapp {

    public static MatierDTO mapMatiertoMatierDTO(MatierDTO Matier){
        MatierDTO matierDTO=new MatierDTO();
        matierDTO.setId(Matier.getId());
        matierDTO.setNomfilier(Matier.getNomfilier());
        matierDTO.setLibelle(Matier.getLibelle());


        return matierDTO;
    }
    public static Matier mapMatierDTOMatier(MatierDTO MatierDTO){
        Matier matier=new Matier();
       matier.setId(MatierDTO.getId());
        matier.setNomfilier(MatierDTO.getNomfilier());
        matier.setLibelle(MatierDTO.getLibelle());

        return matier;
    }
}
