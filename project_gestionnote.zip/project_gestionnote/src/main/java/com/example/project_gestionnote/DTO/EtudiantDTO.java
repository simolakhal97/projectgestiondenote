package com.example.project_gestionnote.DTO;

public class EtudiantDTO {
    private long idE;
    private  String nometudient;
    private String  prenom;
    private String bronch;
    private String email;
    private String Epassword;

    public String getEpassword() {
        return Epassword;
    }

    public void setEpassword(String epassword) {
        Epassword = epassword;
    }

    public long getId() {
        return idE;
    }

    public void setId(long id) {
        this.idE = idE;
    }

    public String getNometudient() {
        return nometudient;
    }

    public void setNometudient(String nometudient) {
        this.nometudient = nometudient;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getBronch() {
        return bronch;
    }

    public void setBronch(String bronch) {
        this.bronch = bronch;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
