package com.example.project_gestionnote.Service.IMP;

import com.example.project_gestionnote.DTO.LoginDTO;
import com.example.project_gestionnote.Mapper.LoginMapp;
import com.example.project_gestionnote.Model.Login;
import com.example.project_gestionnote.Service.LoginService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class LoginIMP implements LoginService {
    public static LoginService loginService;
    public Object LoginService;
    public  LoginIMP(LoginService LoginService){loginService=LoginService;}

    public static LoginMapp loginMapp;
    public  LoginIMP(LoginMapp LoginMapp){loginMapp=LoginMapp;}


    @Override
    public List<LoginDTO> getAllLogin() {
        return loginService
                .getAllLogin().
                stream().
                map(e-> LoginMapp.mapLogintoLoginDTO(e))
                .collect(Collectors.toList());
}

}
