package com.example.project_gestionnote.DTO;

import com.example.project_gestionnote.Model.Admin;
import com.example.project_gestionnote.Model.Login;

import javax.persistence.ManyToOne;

public class AdminDTO {
    private long idA;
    private String nom;
    private String prenom;
    private String EmailAdmin;
    private String PasswordAdmin;

    @ManyToOne
    private Login login;


    public static void save(Admin admin) {
    }
    public static void Add(Admin admin) {
    }
    public static void Updat(Admin admin) {
    }
    public static void delet(Admin admin) {
    }
    public static String  getAdminbyId(int idE) {
        return "Adminedit";
    }


    public String getPasswordAdmin() {
        return PasswordAdmin;
    }

    public void setPasswordAdmin(String passwordAdmin) {
        PasswordAdmin = passwordAdmin;
    }

    public String getEmailAdmin() {
        return EmailAdmin;
    }

    public void setEmailAdmin(String emailAdmin) {
        EmailAdmin = emailAdmin;
    }

    public long getId() {
        return idA;
    }

    public void setId(long id) {
        this.idA = idA;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
}
