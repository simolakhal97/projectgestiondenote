package com.example.project_gestionnote.Model;

import org.springframework.data.annotation.Id;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

public class Login {
    @Id
    @GeneratedValue( strategy= GenerationType.IDENTITY)
    private long idL;
    private String email;
    private String password;

    public Login(long idL, String email, String password) {
        this.idL = idL;
        this.email = email;
        this.password = password;
    }
    @OneToMany( targetEntity=Etudiant.class, mappedBy="Login" )
    private List<Etudiant> etudiantList = new ArrayList<>();

    public Login() {
    }
    @OneToMany( targetEntity=Etudiant.class, mappedBy="Login" )
    private List<Etudiant> etudiants = new ArrayList<>();
    private Etudiant etudiant;

    @OneToMany( targetEntity=Prof.class, mappedBy="Prof" )
    private List<Prof> profs = new ArrayList<>();
    private Prof prof;


    public long getId() {
        return idL;
    }

    public void setId(long id) {
        this.idL = idL;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
