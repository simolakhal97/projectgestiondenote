package com.example.project_gestionnote.Service;
import com.example.project_gestionnote.DTO.MatierDTO;

import java.util.List;

public interface MatierService {
    public List<MatierDTO>getAllMatier();
}
