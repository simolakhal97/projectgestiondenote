package com.example.project_gestionnote.Service.IMP;
import com.example.project_gestionnote.Service.EtudiantService;
import com.example.project_gestionnote.DTO.EtudiantDTO;
import com.example.project_gestionnote.Model.Etudiant;
import com.example.project_gestionnote.Reppo.EtudiantReppo;
import com.example.project_gestionnote.Mapper.EtudiantMapp;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class EtudiantIMP implements EtudiantService{
    public static EtudiantService etudiantService;
    public Object Etudiant;
    public  EtudiantIMP(EtudiantService EtudiantService){etudiantService=EtudiantService;}

    @Override
    public List<EtudiantDTO> getAllEtudiant() {
        return etudiantService
                .getAllEtudiant().
                stream().
                map(e->EtudiantMapp.mapEtudianttoEtudiantDTO(e))
                .collect(Collectors.toList());
    }

}
