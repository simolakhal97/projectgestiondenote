package com.example.project_gestionnote.Mapper;

import com.example.project_gestionnote.DTO.MatierDTO;
import com.example.project_gestionnote.Model.Matier;
import com.example.project_gestionnote.DTO.NoteDTO;
import com.example.project_gestionnote.Model.Note;
public class NoteMapp {

    public static NoteDTO mapNotetoNoteDTO(NoteDTO Note){
        NoteDTO noteDTO=new NoteDTO();
        noteDTO.setId(Note.getId());
        noteDTO.setNotepremier(Note.getNotepremier());
        noteDTO.setNotedernier(Note.getNotedernier());
        noteDTO.setNotetotale(Note.getNotetotale());
        noteDTO.setCoef(Note.getCoef());
        return noteDTO;
    }
    public static Note mapNoteDTONote(NoteDTO NoteDTO){
        Note note=new Note();
        note.setId(NoteDTO.getId());
        note.setNotepremier(NoteDTO.getNotepremier());
        note.setNotedernier(NoteDTO.getNotedernier());
        note.setNotetotale(NoteDTO.getNotetotale());
        note.setCoef(NoteDTO.getCoef());
        return note;
    }
}
