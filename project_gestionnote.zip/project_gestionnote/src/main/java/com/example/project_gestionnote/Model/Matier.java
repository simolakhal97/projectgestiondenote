package com.example.project_gestionnote.Model;

import org.springframework.data.annotation.Id;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Matier {

    @Id @GeneratedValue( strategy= GenerationType.IDENTITY)
    private long idM;
    private String nomfilier;
    private  String libelle;


    @ManyToOne
    @JoinColumn( name="idE" )
    private Etudiant etudiant;


    public Matier() {
    }

    @ManyToOne
    @JoinColumn( name="idP" )
    private Prof prof;

    public Matier(long idM, String nomfilier, String libelle) {
        this.idM = idM;
        this.nomfilier = nomfilier;
        this.libelle = libelle;
    }

    public long getId() {
        return idM;
    }

    public void setId(long id) {
        this.idM = idM;
    }

    public String getNomfilier() {
        return nomfilier;
    }

    public void setNomfilier(String nomfilier) {
        this.nomfilier = nomfilier;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
}
