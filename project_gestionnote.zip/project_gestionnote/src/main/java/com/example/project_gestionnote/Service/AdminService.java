package com.example.project_gestionnote.Service;
import com.example.project_gestionnote.DTO.AdminDTO;
import com.example.project_gestionnote.Model.Admin;
import java.util.List;

public interface AdminService {
    public List<AdminDTO>getAllAdmin();
}
