package com.example.project_gestionnote.Reppo;

import com.example.project_gestionnote.Model.Login;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginReppo extends JpaRepository<Login,Long> {
}
